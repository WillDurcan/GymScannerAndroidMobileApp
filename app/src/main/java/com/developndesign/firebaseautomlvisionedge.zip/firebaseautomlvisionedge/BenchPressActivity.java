package com.developndesign.firebaseautomlvisionedge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class BenchPressActivity extends AppCompatActivity {

    ListView list;
    String[] workoutName={"Standard Bench Press", "Dumbell Bench Press", "Incline Bench Press"};
    String[] workoutReps={"10 Reps X 3 Sets", "20 Reps X 3 Sets", "30 Reps X 3 Sets"};
    Integer[] imgid={R.drawable.benchpress_workout, R.drawable.dumbell_press, R.drawable.incline_press};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bench_press);

//        list=findViewById(R.id.list_Workouts);
//        ActivityCustomListView customListView=new ActivityCustomListView(this, workoutName, workoutReps, imgid);
//        list.setAdapter(customListView);

    }
}
