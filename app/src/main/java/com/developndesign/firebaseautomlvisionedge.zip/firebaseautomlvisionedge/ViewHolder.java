package com.developndesign.firebaseautomlvisionedge;

enum ViewHolder {
}
