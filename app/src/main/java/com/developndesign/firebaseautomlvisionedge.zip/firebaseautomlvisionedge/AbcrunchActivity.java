package com.developndesign.firebaseautomlvisionedge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AbcrunchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abcrunch);
    }
}
